
# Prompt Creation Website

This project is a full-stack application for prompt creation services, using:
- **Frontend**: React
- **Backend**: Node.js with Express

## Setup

### 1. Frontend

1. Navigate to the `frontend` folder.
2. Run `npm install` to install dependencies.
3. Start the frontend with `npm start`.

### 2. Backend

1. Navigate to the `backend` folder.
2. Run `npm install` to install dependencies.
3. Start the server with `node server.js`.
