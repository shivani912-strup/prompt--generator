
const express = require('express');
const app = express();
const PORT = 5000;

app.use(express.json());

// Placeholder routes
app.get('/', (req, res) => res.send('API is running'));

// User login route
app.post('/api/login', (req, res) => {
  // Handle user login (mock response)
  res.json({ message: 'User logged in successfully' });
});

// Start server
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
