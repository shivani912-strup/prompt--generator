
import React from 'react';

function Home() {
  return (
    <div>
      <h1>Welcome to Prompt Creation</h1>
      <p>Your solution for custom prompt generation.</p>
    </div>
  );
}

export default Home;
